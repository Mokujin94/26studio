
# Two Player Chess Game

Two-Player Chess written in Javascript. This program utilizes a graphical user interface (GUI) to display the chessboard and pieces, allowing
players to make moves by clicking and dragging the pieces. The GUI also provides additional features such as move history, 
resign, restart, list of captured pieces and option for rotating the board. <br>
Click **[here](https://jinpa-t.github.io/two-player-chess/)** to play.
