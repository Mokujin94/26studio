# 2D_Minecraft
2D Minecraft. HTML, CSS, vanila JS. weekend project.

Link: https://eloquent-johnson-49ef83.netlify.app/

# GamePlay
- 3 tools to harvest five materials. each tool can harvest one or two specifit materials.
- every 60s your inventory is being renewed and you get one of each material.
- MODIFY - you can modify the world to have chosen amount of trees, rocks and bushes.
- you can only harvest material with access to it. (not underground soil and etc).

#
# entrence screen:
![alt text](https://github.com/ArielMoi/2D_Minecraft/blob/main/img/instructionsEntrenceScreenShot.png)

#
# game:
![alt text](https://github.com/ArielMoi/2D_Minecraft/blob/main/img/gameScreenShot.png)

# 
// TODO:
- add gravity.
- modify reset to modified mode.
