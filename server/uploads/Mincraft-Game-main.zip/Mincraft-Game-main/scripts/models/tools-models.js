export default  {
    shovel: 'shovel',
    pickaxe: 'pickaxe',
    axe: 'axe',
    vacuum: 'vacuum',
}