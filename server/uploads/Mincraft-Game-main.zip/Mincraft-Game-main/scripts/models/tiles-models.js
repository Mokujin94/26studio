export default  {
    soil: 'soil',
    grass: 'grass',
    wood: 'wood',
    stone: 'stone',
    cloud: 'cloud',
    leaves: 'leaves',
    wooder: 'wooder',
    leaveser: 'leaveser',
    gold: 'gold',
    diamond: 'diamond',
    sky: 'sky',
}